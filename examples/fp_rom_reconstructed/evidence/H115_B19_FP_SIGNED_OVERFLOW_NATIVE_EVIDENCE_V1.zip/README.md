# H115-B19 — sign-aware floating-point mantissa overflow (private ROM candidate)

**Status before native execution: STATIC / NOT HISTORICAL / NOT PRODUCTION.**

This package tests the *original* 19-operation-per-iteration FP-RK4 machine
program (`y'=-y`, `h=1/4`) which first failed H115-B16, followed by the
already accepted 51-case H115-B13 arithmetic regression.
It deliberately **does not** use the compensated-sum RK4 workaround.

## Historical evidence and precise limitation

V. M. Glushkov and E. L. Yushchenko (1962), printed pp. 113–115:
- FP model source `3333..3425` handles addition and its exponent alignment.
- When an unsigned magnitude crosses one, the CPU's blocked emergency stop
  skips a machine instruction and routes through `3362..3367`.
- Printed word `3367 = 01 3042 0021 0021` adds positive `1/2` unconditionally
  after the mantissa has been halved at `3366`.
- For a positive overflow that is correct: `(x-1)/2 + 1/2 = x/2`.
- For a negative overflow the signed low-magnitude residue is `-(x-1)`;
  correction must be `-(x-1)/2 - 1/2 = -x/2`.

The H115-B16 native trace diverged at user program pointer `0253`
(after adding `k2+k3 = -113/64`), yielding `+15/64` instead of `-113/64`.
The underlying CPU is unchanged. These observations support a **software
candidate**, not a claim about how a physical Kyiv machine behaved.

## Private machine-code candidate (octal)

```
3367 31 0021 3710 3712   ; if RAM[0021] negative -> 3712, else -> 3710
3710 01 3042 0021 0021   ; positive: +1/2
3711 05 0000 0000 3370   ; jump to common normalization
3712 02 0021 3042 0021   ; negative: value-1/2, NOT 1/2-value
3713 05 0000 0000 3370   ; jump to common normalization
```

The four `3710..3713` words are **not printed in the 1962 source** and are
added only to a private runtime ROM image. `3367` is changed only there;
original source bytes and fixed ROM remain untouched. All earlier seven
private modifications from H115-B13 are also preserved. Historical `3574`
is deliberately not invented or treated as a zero instruction.

### Acceptance gate

A PASS requires all of:
- exact native execution of 42 checkpoints / 38 arithmetic operations of the
  *original* H115-B16 (two complete RK4 steps), including negative overflow;
- exact numerical match against the independently calculated 1962-format FP
  words, including `y(1/4)=1595/2048`, `y(1/2)=2544025/4194304`;
- 51 machine-level B13 regressions, with 39 exact cases and all 12 inexact
  outcomes unchanged relative to accepted H115-B13 evidence;
- execution of the negative branch on original RK4 and positive branch on B13;
- native check of each jump back to `3370`, no host PC update after startup;
- both committed, previously accepted examples re-audited offline;
- unchanged production CPU, historical source, fixed ROM, and pre-existing
  uncommitted `docs/historical/ROADMAP.md`.

There is no automatic canonical ROM update or Git commit. A *failure* generates
one evidence ZIP with a precise HOLD reason plus retained native traces.

## MSYS2 MINGW64 from repository root

Place package ZIP under `tempkyiv/` and extract there. After verifying the
package hash and its internal `PACKAGE_SHA256SUMS.txt`:

```sh
python -B -m unittest discover -s tempkyiv/h115_b19_v1/tests -p 'test_*.py' -v && \
python -B tempkyiv/h115_b19_v1/h115_b19_gate.py --selftest && \
python -B tempkyiv/h115_b19_v1/h115_b19_gate.py --repo . --run && \
git status --short
```

The single resulting file is
`tempkyiv/H115_B19_FP_SIGNED_OVERFLOW_NATIVE_EVIDENCE_V1.zip`.
Send it even if the gate returns HOLD.

## Provenance and reproducibility

- Repository branch: `h114-fp-fast-track-romset`, HEAD prefix `52829c6`.
- B16 original failed native evidence: `reference/B16_ORIGINAL_HOLD.zip`.
- B13 51-case native PASS: `reference/B13_ACCEPTED.zip`.
- B16-R1 compensated RK4 native PASS: `reference/B16_R1_ACCEPTED.zip`.
- Original source/harness/oracle files are separately kept in
  `reference/B16_STAGE/` and `reference/B13_STAGE/` and independently audited.
- Only the two new candidate C++ runners differ from those original files.
- No system claim about physical hardware, undocumented ROM, or rounding
  outside the tested domain is made.
