# H115-B16-R1 — RK4 with bounded intermediate sums

**Status:** machine-code *candidate*, not a native PASS until the user's checkout executes this package. It does NOT repair the FP-ROM addition bug found by H115-B16.

H115-B16, 0252 (`ADD k2,k3`) was the first mismatch: expected −113/64 (`36100000000101`), but CPU returned +15/64 (`01700000000101`), a +2 wrap. All first ten arithmetic commands were bit-exact. This negative control is carried in `reference/B16_HOLD_EVIDENCE_V1.zip`.

This revised RK4 uses the **same 7-word private FP-ROM reconstruction** and the **same production CPU**. The user-side 25-command loop keeps the weighted sum temporarily positive, so every weighted addition combines opposite signs:

`r = (1 + k1/8 + k2/4 + k3/4 + k4/8) - 1`, then `dy = 2 * (r/6)`, so `dy = (k1+2*k2+2*k3+k4)/24 = h*(...)/6` for `h=1/4`. In our exact two-step problem, all intermediates (including division by six) are dyadic. No independent rounding uncertainties contaminate the test.

Entry `0240`, user branch `0271`, back edge `0272`, STOP sentinel `0273` (not executed). The model dispatches and branches autonomously; HOST can set `C=3300` once before the run, and no PC write follows.

**Expected:** 2 RK4 steps; 50 arithmetic operations; 54 dispatcher checkpoints; 2 decisions; 1 back edge; `y(1/4)=1595/2048`, `y(1/2)=2544025/4194304`. Negative gate returns evidence ZIP with `HOLD` and detailed trace. This package changes no tracked files and does not modify source ROM or CPU.

The following remains an **OPEN defect**: addition/subtraction overflow when sums of two FP mantissas cross 1 (observed on same-sign negatives). A passing result here is not an FP-ROM fix, nor an attestation of printed historical bytes or of physical hardware. Source address `3574` stays unknown/unfilled.

Reproduce with MSYS2 MINGW64, repository branch `h114-fp-fast-track-romset` at commit starting `74f4211` with parent `82bcacc0...`, and source/evidence pins in `PINNED_INPUTS.json`:

```sh
python -B h115_b16_r1_gate.py --selftest
python -B h115_b16_r1_gate.py --repo <repository root> --run
```

Evidence: `tempkyiv/H115_B16_R1_FP_RK4_BOUNDED_SUM_EVIDENCE_V1.zip`. Upload this single archive even on HOLD.
