# H115-B16 — native two-step classical RK4 via Kyiv 1962 FP software simulator

**Classification:** private synthetic machine-program integration test, **NOT** restored historical RK4 code and **NOT** a hardware oracle. All machine commands execute via the unmodified `src/main.cpp` production CPU and the private alternative FP ROM based on the 251-word GY1962 printed listing. The canonical ROM and `docs/historical/ROADMAP.md` are never modified.

## Purpose and design

Test the classical fourth-order Runge–Kutta method for the scalar initial value problem

    y' = -y,   y(0) = 1,   h = 1/4,   two steps.

For each step, independently construct actual four RHS values:

    k1 = -y
    k2 = -(y + (h/2)*k1)
    k3 = -(y + (h/2)*k2)
    k4 = -(y + h*k3)
    y  = y + (h/6)*(k1 + 2*k2 + 2*k3 + k4)
    t  = t + h
    d  = 3/8 - t
    if d < 0: exit; else: branch back

The resulting two machine-level time steps have **38** FP arithmetic commands (19 each), **2** modeled opcode-31 condition evaluations, **1** machine back-edge, **42** dispatcher checkpoints. The code uses `01, 02, 11, 12` arithmetic, and `31` for both conditional and unconditional branches. It uses no address modification, no host-injected per-step operands, and no directly executed raw user opcodes.

### Exact rational oracle

| Time | Expected y (rational) | Expected y (decimal) |
|---|---|---|
| 0 | 1 | 1 |
| 1/4 | 1595/2048 | 0.77880859375 |
| 1/2 | 2544025/4194304 | 0.6065428256988525390625 |

The exact RK4 one-step stability factor for this special equation is
`1-h+h^2/2-h^3/6+h^4/24 = 1595/2048` at `h=1/4`.
For both chosen steps **all 38 intermediate arithmetic results are exactly representable** in the 33-bit FP mantissa; no dispute about tie rounding or tolerance is needed. The independent Python oracle calculates `Fraction` values for every machine stage and verifies the checkpoint sequence. The C++ harness embeds word-exact checkpoints; the gate checks the exact C++ source SHA and independently recomputes the oracle. No Python arithmetic replaces CPU execution.

### Address plan (octal)

- FP scratch RAM: `0001–0032`, owned by the 1962 FP simulator; untouched by the user image.
- Data: `0100–0107` (y, t, h, h/2, 2, 6, 0, exit threshold), `0120–0127`, `0130`, `0131` (intermediates).
- User program: `0240–0262` are 19 modeled arithmetic opcodes, `0263` condition, `0264` unconditional back-edge, `0265` STOP sentinel (never executed by the CPU during the accepted run).
- Entry: NK 3000 panel word selects `0240`; CPU starts at `3300` once, then continues entirely under the FP dispatcher.
- Private ROM modifications (not historically attested): `3455→3370`, `3467`, `3470`, `3474`, `3476`, added `3706–3707`, exactly as in accepted H115-B15. **No value is fabricated at unknown 3574.**

## Checks and failure policy

1. `--selftest`: independently verify source-derived B15 evidence, immutable user image, both numerical oracle formulations and 42 checkpoint plan; compile syntax using the included runner (native compilation is performed separately).
2. `--run`: pin Git branch, HEAD, source/fixed ROM SHA-256 and B15 prior package/evidence; reject staged or unrelated tracked changes. Compile the exact production CPU source plus the private harness, with no production file mutation.
3. Execute **one** uninterrupted CPU session, produce all traces, compare all checkpoints including every intermediate variable and the entire final state. Any PC fetch into program RAM, unqualified trampoline, ROM gap, unexpected CPU stop, source mutation, or mismatch becomes HOLD. The evidence ZIP is written even after native HOLD when possible.
4. Do not claim a PASS unless 42/42 checkpoints, 38 arithmetic operations, the two machine decisions and the single back-edge were all observed. The user STOP sentinel is not executed.

### MSYS2 MINGW64 run (from repository root)

Run `python -B h115_b16_gate.py --selftest`, then `python -B h115_b16_gate.py --repo . --run`. The top-level assistant command also verifies the exact distribution SHA and the manifest. The expected evidence file is `tempkyiv/H115_B16_FP_RK4_NATIVE_EVIDENCE_V1.zip`. No source, canonical ROM, or Git mutation is performed.

A native HOLD is valid diagnostic evidence, not a failure of the archive integrity. Do not retry with amended source or fabricated words. Preserve any prior `docs/historical/ROADMAP.md` working-tree changes and unrelated `__pycache__`.

## Scope limits

The historical fixed-point RK4 listing `libs/runge_kutta.txt` is **not** simply relocated. It uses a different arithmetic and scratch ABI, and address modification incompatible with the software FP dispatcher. H115-B16 implements the RK4 algorithm anew with modelled FP commands for `f(y)=-y`; a general RHS callback, vector ODEs, hardware timing and ROM authenticity are not yet established. Success here qualifies this bounded application, not the entire numerical functionality of the 1962 printed simulator.
