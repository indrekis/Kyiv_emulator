# H115-B15 — native explicit Euler ODE through private FP-ROM

## Scope and distinction from RK4

After H115-B14 qualified two true CPU-interpreted loops, this stage runs a **real differential-equation solver**, not another halving-only diagnostic. It integrates the initial-value problem `dy/dt = -y`, `y(0)=1` by explicit forward Euler with `h=1/4`. Four iterations are made using the user's *modeled* floating-point commands fetched through the historical dispatcher. **This is Euler, not Runge–Kutta; it does not establish RK4 compatibility.** The corresponding historical RK4 program (`libs/runge_kutta.txt`) is a different, fixed-point program and cannot run in this FP ROM without adaptation.

The exact dyadic Euler sequence is `y = 3/4, 9/16, 27/64, 81/256` and `t=1`. The analytic continuous-time solution `exp(-1)` is deliberately **not** the numeric oracle. Fraction-exact Euler iteration supplies the expected 41-bit floating point words. The source encodes the independent rational oracle in `inputs/INDEPENDENT_ORACLE.json`; stage tests rederive every fraction and bit pattern.

## User RAM image (octal addresses)

- `0100`: `y`, initial `1` (mutable).
- `0101`: `h=1/4` (constant).
- `0102`: `t=0` (mutable).
- `0103`: exit threshold `7/8` (constant).
- `0104`: temporary `delta` (mutable).
- `0105`: temporary `d=(7/8)-t` (mutable).
- `0230`: `11 0100 0101 0104` — `delta <- h*y`.
- `0231`: `02 0100 0104 0100` — `y <- y-delta`.
- `0232`: `01 0102 0101 0102` — `t <- t+h`.
- `0233`: `02 0103 0102 0105` — `d <- (7/8)-t`.
- `0234`: `31 0105 0235 0236` — continue if `d` nonnegative, else exit.
- `0235`: `31 0000 0230 0230` — unconditional machine back-edge.
- `0236`: opcode `33` **stop sentinel only**, inspected at the `3305` dispatcher boundary, not executed.

The threshold `7/8` rather than `1` makes the stop value *strictly negative* at the fourth iteration; therefore no unverified distinction between positive and negative zero enters the branch decision.

## Acceptance

A single CPU session, with one initial HOST assignment `C=3300`, checks exactly 24 dispatcher checkpoints (four independent arithmetic results and two branch-control checks per iteration, except the final back-edge). It verifies all 16 intermediate arithmetic results, four modeled opcode-31 decisions, three back-edges, unmodified program and constant cells, and the exact final `81/256` encoded in Kyiv's 41-bit format. There are no HOST PC/operand writes after initial setup; each instruction is processed through the actual production CPU and the private ROM interpreter. The ROM's missing `3574` remains unknown; accidental execution triggers `HOLD`.

The tested private ROM modifications, *not historically authenticated*, are `3455`, `3467`, `3470`, `3474`, `3476`, `3706` and `3707`. The 251-word printed 1962 source, `mem/ROM.txt` and `src/main.cpp` remain byte-identical. Prior B14 evidence is bundled and hash-verified, not re-executed. `docs/historical/ROADMAP.md` and existing `__pycache__` are not touched. No Git writes.

## Run (MSYS2 MINGW64, repository root)

```bash
test "$(git rev-parse HEAD)" = "82bcacc0ad0e96abc23b98616b6390aa7715d3f6" && \
python -B -m unittest discover -s tempkyiv/h115_b15_v1/tests -p 'test_*.py' -v && \
python -B tempkyiv/h115_b15_v1/h115_b15_gate.py --selftest && \
python -B tempkyiv/h115_b15_v1/h115_b15_gate.py --repo . --run && \
git status --short
```

Return only `tempkyiv/H115_B15_FP_EULER_ODE_EVIDENCE_V1.zip`, including if HOLD. If HOLD, do **not** repair canonical sources or CPU on speculation.
