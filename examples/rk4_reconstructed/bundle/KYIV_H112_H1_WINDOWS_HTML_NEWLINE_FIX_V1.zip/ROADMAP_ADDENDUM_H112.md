# Proposed ROADMAP addendum — H109 to H112

> **NOT applied.** The historical ROADMAP file is intentionally untouched to preserve the user's existing uncommitted work.

## Vector RK4 demonstration milestone — accepted evidence

- **H109 ACCEPTED**: Full n=2 RK4 for constant synthetic machine RHS; 7 native scenarios, 1116 trajectory points, 1000-step long run, actual IO22 output via H103.
- **H110-H2 ACCEPTED**: Coupled oscillator y1'=y2, y2'=-y1, 11 native scenarios, 1146 trajectory points, exact rational RK4 and analytic sin/cos checks.
- **H111 ACCEPTED**: Coupled hyperbolic system y1'=y2, y2'=y1, 11 native scenarios, 1146 trajectory points, exact rational RK4 and analytic sinh/cosh checks.
- **H112 OFFLINE AUDIT PASS / NATIVE REPLAY OPTIONAL**: Retained evidence and source runner packages SHA-pinned; 29 cases and 3408 raw41 trajectory points independently rechecked. Self-contained HTML demonstrator and three-system native replay runner provided.

### Scope qualification

Functional reconstruction, **not** historical printer/ROM proof. Historical words 3200 and 3677 remain unknown. H103 group ROM and all RHS callbacks are reconstructed/synthetic. H81 scratch assumptions persist; n>2 machine integration is unqualified, even though H103 prints n=1..8. Keep this boundary visible in user-facing release notes.

### Possible follow-up after evidence release

One larger integration milestone can add source-controlled executable demos, CI, clean checkout test, and release notes, provided upstream maintainers approve source changes. Avoid changing historical canonical memory and CPU code in the evidence-only phase.
