# H112 — release readiness, provenance and limitations

## Classification

**READY FOR REVIEW: RECONSTRUCTED FUNCTIONAL DEMONSTRATION**, not historical ROM restoration or a new production software release. H112's offline status is a validation of retained native execution evidence, not a fresh execution of the CPU. Native replay is available as an optional independent operation.

### What the evidence demonstrates

1. Historical RK source word range **3600–3676** executes unchanged in the emulator's production CPU. The missing original word **3677** is not replaced with a historical claim.
2. Experimental alternate ROM at **3200**, H103 machine code at **3400...**, and actual machine IO22 (host octal14 preview mode) produce the values after natural RK4 completion; original historical `3200` has not been discovered.
3. H109: n=2 vector RK4, two constant synthetic RHS components, 7 accepted native cases, up to 1000 steps.
4. H110-H2: n=2 vector RK4 of the coupled oscillator y1'=y2; y2'=-y1, 11 accepted native cases, up to 1000 steps.
5. H111: n=2 vector RK4 of the coupled hyperbolic system y1'=y2; y2'=y1, 11 accepted native cases, up to 1000 steps.
6. Machine output includes actual 41-bit sign-magnitude words for descriptor, x, y1, y2. Decimal graphs are **host decode** of these words.
7. Exact rational arithmetic produces RK4 mathematical oracles, distinct from the analytic sin/cos and sinh/cosh solutions; evidence separates method error from machine arithmetic error.
8. H103 additionally qualifies dynamic IO22 printing for n=1..8; this **does not** qualify integrating systems of dimension n>2.

### Not demonstrated / not authentic

- Original ROM 3200 and missing word 3677.
- Authentic printer hardware or historical printer byte layout; current octal14 is HOST preview.
- Historical operator switch settings, primary preparation, or fully source-authenticated memory initialization: scratch cells 0005..0007 and 0012 remain reconstruction assumptions; unknown shadows remain unknown.
- Correctness of n>2 full vector RK4, arbitrary callback functions or arbitrary operator inputs.
- Clock-accurate/physical gate-level hardware timings.

### Artifact dependencies

| Archive | Nature | Acceptance |
|---|---|---|
| H103 | Reconstructed group loop ROM and machine IO22 | PASS, n=1..8 printing |
| H108 | Native evidence for n=2 RHS consumption | PASS |
| H109 | n=2 constant RHS full RK4 | PASS, 7 cases |
| H110-H2 | n=2 coupled oscillator | PASS, 11 cases |
| H111 | n=2 hyperbolic coupled system | PASS, 11 cases |

The nested ZIP files and their SHA-256, including stage-to-stage hashes, are pinned by `PINNED_INPUTS_H112.json`. The H112 audit refuses mutated or incomplete input archives. `H112_NATIVE_REPLAY` is opt-in and requires the original checkout and build environment.

### Release recommendation

A bounded demonstration labeled **"reconstructed functional RK4 n=2"** is evidence-ready. Any broader emulator release requires separate integration testing, license/provenance review of redistributed historical sources and a release decision by the repository maintainer. The historical PDFs have **not** been included in this H112 package.
