#!/usr/bin/env python3
"""Create dependency-free offline HTML demonstration from audited H112 evidence."""
from __future__ import annotations
import argparse,csv,html,io,json,math,zipfile
from pathlib import Path
from fractions import Fraction
from h112_audit import audit,STAGES,signed_word

LABEL={109:'Сталі похідні',110:'Осцилятор',111:'Гіперболічна система'}
EQUATION={109:"y₁′ = 1; y₂′ = −½",110:"y₁′ = y₂; y₂′ = −y₁",111:"y₁′ = y₂; y₂′ = y₁"}
COLORS={109:'#77a5ef',110:'#eaab73',111:'#61d4b0'}

def load(root:Path):
    all_lines={}; result={}
    for stage in (109,110,111):
        with zipfile.ZipFile(root/'evidence'/STAGES[stage]) as z:
            j=json.loads(z.read(f'RESULT_H{stage}.json'));result[stage]=j
            case='n1000_negative_pattern' if stage==109 else 'n1000'
            with z.open(f'TRAJECTORY_H{stage}.tsv') as f:
                rows=csv.DictReader(io.TextIOWrapper(f,encoding='utf8'),delimiter='\t')
                all_lines[stage]=[(float(Fraction(r['x'])),float(signed_word(r['y1_raw41'])),float(signed_word(r['y2_raw41']))) for r in rows if r['case']==case]
            assert len(all_lines[stage])==1000
    return all_lines,result

def plot(data,idx,title):
    W,H=980,330;L,R,T,B=70,28,28,46
    XMAX=max(pt[0] for points in data.values() for pt in points)
    values=[pt[idx] for points in data.values() for pt in points]
    ymin,ymax=min(values+[0]),max(values+[0]);span=ymax-ymin or 1
    ymin-=span*0.08;ymax+=span*0.08
    x=lambda v:L+(W-L-R)*v/XMAX
    y=lambda v:T+(H-T-B)*(ymax-v)/(ymax-ymin)
    out=[f'<svg viewBox="0 0 {W} {H}" role="img" aria-label="{html.escape(title)}" xmlns="http://www.w3.org/2000/svg">']
    for i in range(5):
        v=ymin+(ymax-ymin)*i/4;py=y(v)
        out.append(f'<line x1="{L}" y1="{py:.1f}" x2="{W-R}" y2="{py:.1f}" stroke="#2d4055" stroke-width="1"/>')
        out.append(f'<text x="{L-9}" y="{py+4:.1f}" fill="#9eafc4" text-anchor="end" font-size="12">{v:.3f}</text>')
    for i in range(5):
        v=XMAX*i/4;px=x(v)
        out.append(f'<line x1="{px:.1f}" y1="{T}" x2="{px:.1f}" y2="{H-B}" stroke="#243346"/>')
        out.append(f'<text x="{px:.1f}" y="{H-16}" fill="#9eafc4" text-anchor="middle" font-size="12">{v:.3f}</text>')
    out.append(f'<text x="{W-R}" y="{H-6}" fill="#bccbdc" text-anchor="end" font-size="12">x</text>')
    for k,pts in data.items():
        points=pts[::7]+([pts[-1]] if pts[-1] not in pts[::7] else [])
        d=' '.join(('M' if i==0 else 'L')+f'{x(pt[0]):.2f},{y(pt[idx]):.2f}' for i,pt in enumerate(points))
        out.append(f'<path d="{d}" fill="none" stroke="{COLORS[k]}" stroke-width="2.8" stroke-linejoin="round"/>')
    out.append('</svg>')
    return ''.join(out)

def render(root:Path,out:Path):
    result=audit(root)
    data,cases=load(root)
    rowhtml=[]
    for stage in (109,110,111):
        info=cases[stage]['cases']['n1000_negative_pattern' if stage==109 else 'n1000']
        p=data[stage][-1]
        raw=' · '.join(info['output_raw41'])
        rowhtml.append(f'<tr><td><span class="dot" style="background:{COLORS[stage]}"></span><b>H{stage}: {LABEL[stage]}</b><div class="dim">{EQUATION[stage]}</div></td><td>{info["native_instructions"]:,}</td><td>{p[1]:.10f}</td><td>{p[2]:.10f}</td><td><code>{info["output_raw41"][2]}</code> / <code>{info["output_raw41"][3]}</code></td></tr>')
    conv=[]
    for stg in (110,111):
        vals=[float(v) for v in cases[stg]['cross_case']['ideal_method_error_xquarter']]
        conv.append(f'<tr><td>H{stg} — {LABEL[stg]}</td>'+''.join(f'<td>{v:.3e}</td>' for v in vals)+
                    f'<td>{vals[0]/vals[1]:.2f} / {vals[1]/vals[2]:.2f} / {vals[2]/vals[3]:.2f}</td></tr>')
    body=f'''<!doctype html><html lang="uk"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>ЕОМ «Київ» — реконструйований RK4, демонстрація H112</title>
<style>
:root{{--ink:#eef5fc;--soft:#adbed0;--line:#26384c;--card:#152337;--bg:#0b1421}}
*{{box-sizing:border-box}}body{{margin:0;background:var(--bg);color:var(--ink);font:16px/1.55 system-ui,Segoe UI,Arial,sans-serif}}
main{{max-width:1150px;padding:44px 28px 75px;margin:auto}}
header{{border-bottom:1px solid var(--line);padding-bottom:30px;margin-bottom:28px}}
h1{{font-size:clamp(2rem,4vw,3rem);line-height:1.17;margin:10px 0}}h2{{font-size:1.45rem;margin-top:36px}}
p{{color:var(--soft);max-width:950px}}.eyebrow{{font-size:.8rem;letter-spacing:.13em;text-transform:uppercase;color:#61d4b0;font-weight:750}}
.dim{{font-size:.82rem;color:var(--soft)}}.grid{{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:15px}}
.metric{{background:var(--card);border:1px solid var(--line);padding:20px;border-radius:12px}}.metric strong{{display:block;font-size:2rem;color:var(--ink)}}
.panel{{background:var(--card);padding:20px 24px;border:1px solid var(--line);border-radius:12px;margin-top:16px}}
.panel svg{{display:block;width:100%;height:auto}}
table{{border-collapse:collapse;width:100%;font-size:.91rem}}th,td{{border-bottom:1px solid var(--line);text-align:left;padding:12px 10px;vertical-align:top}}th{{color:#a6c2db;font-weight:650}}
.tablewrap{{overflow-x:auto}}code{{background:#243247;border-radius:3px;padding:2px 4px;white-space:nowrap;font-size:.82em}}
.dot{{display:inline-block;width:9px;height:9px;border-radius:50%;margin-right:8px}}
.legend{{display:flex;flex-wrap:wrap;gap:18px;margin-top:10px;color:var(--soft);font-size:.88rem}}
.warning{{border-left:3px solid #eaab73;padding:10px 18px;background:#1c2632;border-radius:4px}}
footer{{border-top:1px solid var(--line);margin-top:40px;padding-top:20px;color:var(--soft);font-size:.82rem}}
@media(max-width:700px){{.grid{{grid-template-columns:1fr}}main{{padding:28px 15px}}.panel{{padding:15px}}}}
</style></head><body><main><header><div class="eyebrow">H112 · evidence-backed reconstruction · offline</div>
<h1>Чисельне інтегрування на ЕОМ «Київ»</h1>
<p>Три системи диференціальних рівнянь, оригінальний машинний модуль Рунге—Кутти (адреси 3600–3676), синтетичні машинні праві частини та реконструйований циклічний вивід через H103. Звіт створений виключно з перевірених native evidence H109–H111.</p></header>
<section class="grid"><div class="metric"><strong>29</strong>native-сценаріїв H109–H111</div><div class="metric"><strong>3 408</strong>перевірених точок траєкторій</div><div class="metric"><strong>1 000</strong>кроків у кожній довгій серії</div></section>
<h2>Довгі native-прогони: 1000 кроків</h2><p>Спільна сітка: h = 1/4096, кінцеве x = 1000/4096 = 0,244140625. На графіках показано декодовані 41-бітові машинні значення; криві дискретизовані лише для зручності візуалізації. Жодні проміжні дані не замінені аналітичним розв'язком.</p>
<div class="panel"><h3>Перша компонента y₁(x)</h3>{plot(data,1,'Перша компонента, три системи')}</div>
<div class="panel"><h3>Друга компонента y₂(x)</h3>{plot(data,2,'Друга компонента, три системи')}</div>
<div class="legend">{''.join(f'<span><span class="dot" style="background:{COLORS[s]}"></span>{LABEL[s]}</span>' for s in (109,110,111))}</div>
<h2>Фактичний результат машинного друку IO22</h2><div class="panel tablewrap"><table><thead><tr><th>Система</th><th>Команд</th><th>y₁</th><th>y₂</th><th>Кінцеві raw41 (вісімкова система)</th></tr></thead><tbody>{''.join(rowhtml)}</tbody></table></div>
<h2>Збіжність і незалежний математичний еталон</h2><p>Похибка <b>ідеального RK4 у точній раціональній арифметиці</b> відносно аналітичного розв'язку на фіксованому інтервалі x = 1/4. Розділена з похибкою 40-бітового машинного виконання. Для RK4 очікуване зменшення похибки наближається до 16× при подвоєнні числа кроків.</p>
<div class="panel tablewrap"><table><thead><tr><th>Система</th><th>2 кроки</th><th>4 кроки</th><th>8 кроків</th><th>16 кроків</th><th>Відношення</th></tr></thead><tbody>{''.join(conv)}</tbody></table></div>
<h2>Що підтверджено, а що залишається невідомим</h2>
<div class="panel"><p><b>Підтверджено:</b> виконання оригінальних команд RK4 для n=2, реальні машинні обчислення RHS, повторюваність і перевірка довгих траєкторій, фактичний груповий IO22, точний раціональний та аналітичний еталони.</p>
<div class="warning"><b>Не підтверджено історично:</b> невідомий вміст ПСП за адресами 3200 і 3677; початковий операторський процес; автентичний формат друку; векторний RK4 для n&gt;2; такти та схема апаратного обчислювача. H103 — функціональна реконструкція друку, а RHS — синтетичні машинні підпрограми.</div></div>
<footer>H112 · Портативний офлайновий огляд. Первинні архіви, інструменти й SHA-256 в цій же поставці. Для повторної перевірки: <code>python h112_audit.py</code>. Для native-replay потрібен репозиторій та середовище збірки.</footer>
</main></body></html>'''
    out.parent.mkdir(parents=True,exist_ok=True)
    # Canonical LF UTF-8 bytes on Windows/MSYS2 as well as POSIX.
    # Path.write_text() translates '\n' to CRLF on Windows and breaks
    # the byte-for-byte evidence regeneration check.
    out.write_bytes(body.encode('utf-8'))
    return {'status':'PASS_H112_HTML_FROM_PINNED_NATIVE_EVIDENCE', 'html_bytes':out.stat().st_size,
            'scenarios':result['native_scenarios_reexamined'],'trajectory_points':result['trajectory_points_reexamined']}

def main():
    p=argparse.ArgumentParser();p.add_argument('--bundle',type=Path,default=Path(__file__).resolve().parent)
    p.add_argument('--out',type=Path,default=Path(__file__).resolve().parent/'DEMO_H112.html');args=p.parse_args()
    r=render(args.bundle.resolve(),args.out.resolve());print('H112_HTML_STATUS='+r['status']);print('H112_HTML_BYTES='+str(r['html_bytes']))
if __name__=='__main__': main()
