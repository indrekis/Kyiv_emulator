# Source / assumption scope: H112-H1

| Item | Classification | Consequence |
|---|---|---|
| H103/H108/H109/H110-H2/H111 evidence and native source bundles | NATIVE_OBSERVATION (retained evidence) / RECONSTRUCTED_ASSUMPTION (code) | Byte-identical to original H112 bundle. No new native behavior is claimed by H112-H1. |
| `PINNED_INPUTS_H112.json`, `RESULT_H112.json`, `DEMO_H112.html` | Accepted H112 offline verification and host representation | Byte-identical to H112. |
| `h112_report.py` | HOST_POLICY (report serialization only) | Writes UTF-8/LF bytes directly. Does not alter any numerical or machine value. |
| `test_h112_h1.py`, `BASELINE_H112_H1.json` | SYNTHETIC_TEST / traceability | Guard cross-platform bytes and unchanged evidence. |
| `h112_audit.py`, `h112_replay.py`, `test_h112.py` | H112 acceptance code | Byte-identical to H112. |
| `mem/ROM.txt`, fixed historical words `3200`/`3677` | Historical source / unknown | Not edited; no restoration asserted. |

No general `n>2` RK4 correctness, authentic historical printer format, or historical operator initialization is asserted; the H112 bounded release scope remains unchanged. The unrelated uncommitted `docs/historical/ROADMAP.md` must be preserved.
