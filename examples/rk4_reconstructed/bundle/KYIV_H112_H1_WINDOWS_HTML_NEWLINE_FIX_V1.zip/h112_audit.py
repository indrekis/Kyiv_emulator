#!/usr/bin/env python3
"""H112 offline release-candidate audit. Python standard library only.

No CPU execution or modification; independently validates pinned nested evidence,
source package hashes, trajectories, IO22 raw 41-bit words and dependency links.
"""
from __future__ import annotations
import argparse, collections, csv, hashlib, io, json, re, sys, zipfile
from fractions import Fraction
from pathlib import Path

CASES = {109: 7, 110: 11, 111: 11}
STATUS = {
  103:'PASS_H103_GROUP_26_27_RUNTIME_ALPHA_N1_TO_N8_NATIVE_IO22',
  108:'PASS_H108_VECTOR_N2_ORIGINAL_FIRST_STAGE_TWO_RHS_CONSUMED_NOT_FULL_RK4',
  109:'PASS_H109_VECTOR_N2_FULL_RK4_CONSTANT_RHS_GROUP_ROM_IO22',
  110:'PASS_H110_COUPLED_VECTOR_N2_RK4_MACHINE_RHS_H103_IO22',
  111:'PASS_H111_HYPERBOLIC_COUPLED_VECTOR_RK4_NATIVE_IO22',
}
STAGES = {
  103:'H103_GROUP_ALPHA_NATIVE_EVIDENCE_H2_V1.zip',
  108:'H108_VECTOR_N2_FIRST_STAGE_EVIDENCE_V1.zip',
  109:'H109_VECTOR_N2_FULL_NATIVE_EVIDENCE_V1.zip',
  110:'H110_COUPLED_VECTOR_NATIVE_EVIDENCE_H2_V1.zip',
  111:'H111_HYPERBOLIC_COUPLED_NATIVE_EVIDENCE_V1.zip',
}
OCTAL14=re.compile(r'^[0-7]{14}$')
LIMIT=(1<<41)-1
MAG=(1<<40)-1

def sha(b: bytes)->str: return hashlib.sha256(b).hexdigest()
def check(cond, message):
    if not cond: raise ValueError(message)
def signed_word(w:str)->Fraction:
    check(bool(OCTAL14.fullmatch(w)),f'invalid raw 41-bit octal word: {w!r}')
    i=int(w,8);check(0 <= i<=LIMIT,f'41-bit overflow: {w}')
    return Fraction((-1 if i>>40 else 1)*(i&MAG),1<<40)
def internal_integrity(z:zipfile.ZipFile, label:str)->int:
    names=z.namelist()
    check(len(set(names))==len(names),f'{label}: duplicate ZIP members')
    for name in names:
        check(not name.startswith('/') and not name.startswith('\\') and
              '..' not in Path(name.replace('\\','/')).parts and not re.match(r'^[A-Za-z]:',name),
              f'{label}: unsafe ZIP member {name}')
    check(z.testzip() is None,f'{label}: ZIP CRC')
    sums=[n for n in names if n.endswith('SHA256SUMS.txt')]
    check(len(sums)==1, f'{label}: missing/duplicate SHA256SUMS')
    count=0
    for line in z.read(sums[0]).decode('utf8').splitlines():
        if not line.strip():continue
        m=re.fullmatch(r'([0-9a-f]{64})\s+\*?(.+)',line)
        check(m is not None,f'{label}: malformed SHA line')
        expected,name=m.groups();check(name in names,f'{label}: unlisted {name}')
        check(sha(z.read(name))==expected,f'{label}: altered member {name}')
        count+=1
    check(count==len([s for s in names if s!=sums[0] and not s.endswith('/')]), f'{label}: incomplete manifest')
    return count

def audit(root: Path)->dict:
    pins=json.loads((root/'PINNED_INPUTS_H112.json').read_text(encoding='utf8'))
    check(pins['schema']=='H112_PINNED_ARCHIVES_V1','wrong pins schema')
    pinmap={p['path']:p for p in pins['inputs']}
    check(len(pinmap)==8,'unexpected H112 pinned archive count')
    for rel,entry in pinmap.items():
        p=root/rel
        check(p.is_file(),f'missing pinned file {rel}')
        b=p.read_bytes()
        check(len(b)==entry['bytes'] and sha(b)==entry['sha256'],f'PIN_MISMATCH:{rel}')
        with zipfile.ZipFile(io.BytesIO(b)) as z: internal_integrity(z,rel)
    summaries={}; total_points=0
    for stage,filename in STAGES.items():
        archive=root/'evidence'/filename
        with zipfile.ZipFile(archive) as z:
            j=json.loads(z.read(f'RESULT_H{stage}.json'))
            check(j['status']==STATUS[stage],f'H{stage}: wrong status')
            if stage>=109:
                check(len(j['cases'])==CASES[stage],f'H{stage}: wrong case count')
                cases=j['cases']; actual=collections.defaultdict(list)
                with z.open(f'TRAJECTORY_H{stage}.tsv') as f:
                    reader=csv.DictReader(io.TextIOWrapper(f,encoding='utf8'),delimiter='\t',strict=True)
                    check(len(reader.fieldnames)==len(set(reader.fieldnames)),f'H{stage}: repeated TSV field')
                    required=('case','step','x','y1_raw41','y2_raw41','y1_fraction','y2_fraction')
                    check(all(k in reader.fieldnames for k in required),f'H{stage}: missing trajectory field')
                    for row in reader:
                        key=row['case'];check(key in cases,f'H{stage}: extraneous case {key}')
                        step=int(row['step']);check(step>0,f'H{stage}: bad step')
                        expected_x=step*Fraction(cases[key]['h'])
                        check(Fraction(row['x'])==expected_x,f'H{stage}/{key} step{step}: x mismatch')
                        for axis in ('y1','y2'):
                            actual_fraction=signed_word(row[axis+'_raw41'])
                            check(actual_fraction==Fraction(row[axis+'_fraction']),
                                  f'H{stage}/{key} step{step}: {axis} raw41/fraction disagree')
                        actual[key].append((step,row))
                check(set(actual)==set(cases),f'H{stage}: incomplete case coverage')
                numpoints=0
                for key,case in cases.items():
                    check(case['status']=='PASS' and not case['errors'],f'H{stage}/{key}: case not passed')
                    rows=actual[key];n=case['n'];check(case['points']==n and len(rows)==n,
                              f'H{stage}/{key}: trajectory count')
                    check([s for s,_ in rows]==list(range(1,n+1)),f'H{stage}/{key}: step gap')
                    check(case['native_instructions']== (209*n+32 if stage==109 else 213*n+32),
                          f'H{stage}/{key}: instruction count')
                    if stage in (110,111):check(case['RHS_calls']==4*n,f'H{stage}/{key}: RHS count')
                    check(len(case['output_raw41'])==4,f'H{stage}/{key}: IO22 count')
                    for w in case['output_raw41']:signed_word(w)
                    last=rows[-1][1]
                    check(case['output_raw41'][0]=='00000000020000',f'H{stage}/{key}: descriptor')
                    check(case['output_raw41'][1] == f'{int(Fraction(last["x"])*(1<<40)):014o}',
                          f'H{stage}/{key}: x output differs')
                    for i,axis in ((2,'y1'),(3,'y2')):
                        check(case['output_raw41'][i]==last[axis+'_raw41'],
                              f'H{stage}/{key}: IO22 {axis} differs from trajectory')
                    numpoints+=n
                check(numpoints==sum(c['points'] for c in cases.values()),f'H{stage}: points total')
                total_points+=numpoints
                summaries[stage]={'status':j['status'],'native_cases':len(cases),
                                  'trajectory_points':numpoints,
                                  'max_step':max(c['n'] for c in cases.values()),
                                  'max_instructions':max(c['native_instructions'] for c in cases.values()),
                                  'case_names':sorted(cases)}
            else:
                check(len(j['cases'])>=3,f'H{stage}: missing qualification cases')
                summaries[stage]={'status':j['status'],'native_cases':len(j['cases'])}
            # The chain is from the ORIGINAL accepted input archives, not a circular self-reference.
            for dependency in (103,108,109,110):
                fields={103:['h103_evidence_sha256'],108:['h108_evidence_sha256'],
                        109:['h109_evidence_sha256'],110:['h110_evidence_sha256']}[dependency]
                if stage>dependency and any(f in j for f in fields):
                    check(j[fields[0]] == pinmap[f'evidence/{STAGES[dependency]}']['sha256'],
                          f'H{stage} has incorrect H{dependency} dependency pin')
    check(summaries[109]['trajectory_points']==1116, 'H109 unexpected point total')
    check(summaries[110]['trajectory_points']==1146, 'H110 unexpected point total')
    check(summaries[111]['trajectory_points']==1146, 'H111 unexpected point total')
    return {'status':'PASS_H112_OFFLINE_EVIDENCE_AUDIT', 'schema':'H112_RELEASE_CANDIDATE_V1',
            'pinned_archives':len(pinmap),'nested_sha_verified':True,
            'native_scenarios_reexamined':sum(summaries[s]['native_cases'] for s in (109,110,111)),
            'trajectory_points_reexamined':total_points,
            'stages':{str(k):v for k,v in summaries.items()},
            'limitations':['No historical ROM 3200 or 3677 reconstruction claimed',
                           'Complete vector RK4 verified only for n=2',
                           'Synthetic machine RHS and H103 printer are reconstructed',
                           'Offline audit rechecks archived evidence; does not execute the native CPU']}

def main():
    p=argparse.ArgumentParser();p.add_argument('--bundle',type=Path,default=Path(__file__).resolve().parent)
    p.add_argument('--out',type=Path);args=p.parse_args()
    try:
        result=audit(args.bundle.resolve())
        if args.out:
            args.out.mkdir(parents=True,exist_ok=True)
            (args.out/'RESULT_H112.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
        print('H112_STATUS='+result['status'])
        print('H112_RECHECKED_CASES='+str(result['native_scenarios_reexamined']))
        print('H112_RECHECKED_POINTS='+str(result['trajectory_points_reexamined']))
    except Exception as e:
        print('H112_STATUS=HOLD_H112_OFFLINE_AUDIT',file=sys.stderr)
        print('H112_ERROR='+repr(e),file=sys.stderr)
        sys.exit(1)
if __name__=='__main__':main()
