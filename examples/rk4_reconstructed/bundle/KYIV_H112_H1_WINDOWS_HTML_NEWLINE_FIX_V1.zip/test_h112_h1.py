#!/usr/bin/env python3
"""Windows/POSIX newline regression and original-H112 provenance gates."""
import hashlib
import json
import tempfile
import unittest
from pathlib import Path
from unittest import mock

HERE = Path(__file__).resolve().parent
from h112_report import render

HTML_SHA = '58f4ea65fa78e4f676bc748a1202ed16e8581884223e83c96fde5c842a5d3812'

def sha(b): return hashlib.sha256(b).hexdigest()

class H112H1(unittest.TestCase):
    def test_original_html_is_lf_only_and_sha_pinned(self):
        b = (HERE/'DEMO_H112.html').read_bytes()
        self.assertIn(b'\n', b)
        self.assertNotIn(b'\r\n', b)
        self.assertEqual(sha(b), HTML_SHA)

    def test_renderer_avoids_platform_text_translation(self):
        # This fails if a future generator reintroduces Path.write_text.
        # Force text writes to fail on every OS (simulates the Windows hazard).
        with tempfile.TemporaryDirectory() as d:
            target = Path(d)/'render.html'
            with mock.patch.object(Path, 'write_text', side_effect=AssertionError('PLATFORM_DEPENDENT_TEXT_WRITE')):
                r = render(HERE,target)
            self.assertEqual(r['status'], 'PASS_H112_HTML_FROM_PINNED_NATIVE_EVIDENCE')
            self.assertEqual(target.read_bytes(), (HERE/'DEMO_H112.html').read_bytes())
            self.assertNotIn(b'\r\n',target.read_bytes())

    def test_immutable_members_match_original_h112(self):
        d = json.loads((HERE/'BASELINE_H112_H1.json').read_text(encoding='utf-8'))
        self.assertEqual(d['schema'],'H112_H1_ORIGINAL_IMMUTABLE_FILES_SHA256_V1')
        self.assertEqual(len(d['baseline_files_sha256']),17)
        for rel, expected in d['baseline_files_sha256'].items():
            with self.subTest(rel=rel):
                self.assertEqual(sha((HERE/rel).read_bytes()),expected)

    def test_new_generator_is_only_changed_original_code(self):
        s=(HERE/'h112_report.py').read_text(encoding='utf-8')
        self.assertIn("out.write_bytes(body.encode('utf-8'))",s)
        self.assertNotIn('out.write_text(body',s)
        self.assertEqual((HERE/'DEMO_H112.html').read_bytes().count(b'\n'),
                         (HERE/'DEMO_H112.html').read_bytes().count(b'\x0a'))

    def test_manifest_complete_and_valid(self):
        m={}
        for ln in (HERE/'PACKAGE_SHA256SUMS.txt').read_text(encoding='utf-8').splitlines():
            digest,rel=ln.split('  ',1)
            self.assertNotIn(rel,m)
            m[rel]=digest
        actual={p.relative_to(HERE).as_posix() for p in HERE.rglob('*')
                if p.is_file() and p.name!='PACKAGE_SHA256SUMS.txt' and '__pycache__' not in p.parts}
        self.assertEqual(set(m),actual)
        for rel,digest in m.items():
            self.assertEqual(sha((HERE/rel).read_bytes()),digest,rel)

if __name__=='__main__':unittest.main(verbosity=2)
