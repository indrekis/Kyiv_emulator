# H112-H1 — Windows/MSYS2 deterministic HTML regeneration

## Diagnosis and scope

The H112 regression `test_html_regeneration_from_evidence` passes on POSIX but fails on Windows Python because `h112_report.py` wrote HTML through `Path.write_text()`. Windows converts LF newlines in text mode to CRLF. The archived authoritative `DEMO_H112.html` uses LF, so an exact-byte comparison fails even though the HTML is equivalent.

**H112-H1 is a narrowly bounded portable-report correction, not a new native CPU claim.** Changed original source: only `h112_report.py` (replace `Path.write_text(body, encoding='utf8')` by `Path.write_bytes(body.encode('utf-8'))`); the original manifest is regenerated for the new bundle. All original HTML, evidence, pinned inputs, native runner archives, H112 audit/replay code, earlier test code, release scope and roadmap addendum are retained **byte for byte**. `BASELINE_H112_H1.json` pins their hashes against the original H112 artifact.

The new `test_h112_h1.py` checks LF-only output, absence of reliance on `Path.write_text`, byte-identical output to the original HTML, unchanged original artifacts, and manifest coverage. Original 13 H112 tests remain mandatory.

## Usage from the repository root (Windows 11 MSYS2 MINGW64)

Put `KYIV_H112_H1_WINDOWS_HTML_NEWLINE_FIX_V1.zip` in `tempkyiv/`, then run:

```bash
mkdir -p tempkyiv/h112_h1_tool && \
unzip -o tempkyiv/KYIV_H112_H1_WINDOWS_HTML_NEWLINE_FIX_V1.zip \
  -d tempkyiv/h112_h1_tool && \
(cd tempkyiv/h112_h1_tool && sha256sum -c PACKAGE_SHA256SUMS.txt) && \
python tempkyiv/h112_h1_tool/test_h112_h1.py && \
python tempkyiv/h112_h1_tool/test_h112.py && \
python tempkyiv/h112_h1_tool/h112_audit.py \
  --out tempkyiv/H112_H1_OFFLINE_AUDIT && \
python tempkyiv/h112_h1_tool/h112_report.py \
  --out tempkyiv/H112_H1_DEMO.html && \
python -c "from pathlib import Path; import sys; a=Path('tempkyiv/H112_H1_DEMO.html').read_bytes(); b=Path('tempkyiv/h112_h1_tool/DEMO_H112.html').read_bytes(); print('H112_H1_HTML_EXACT_BYTES='+str(a==b)); sys.exit(0 if a==b else 1)" && \
git diff --check && git status --short
```

The original HTML report's SHA-256 must remain `58f4ea65fa78e4f676bc748a1202ed16e8581884223e83c96fde5c842a5d3812`. Expected audit status: `PASS_H112_OFFLINE_EVIDENCE_AUDIT`, 29 native scenarios and 3408 trajectory points. This status is an *offline evidence re-audit*, **not a new native execution**.

## Optional native replay

If needed after the offline checks:

```bash
python tempkyiv/h112_h1_tool/h112_replay.py \
  --repo . --out tempkyiv/H112_H1_NATIVE_REPLAY && \
git diff --check && git status --short
```

This invokes the unchanged native-replay contract from H112. Do not overwrite previous replay/evidence directories. H112-H1 does not touch `mem/ROM.txt`, historical RK4 code, production CPU, or existing user edits to `docs/historical/ROADMAP.md`.
