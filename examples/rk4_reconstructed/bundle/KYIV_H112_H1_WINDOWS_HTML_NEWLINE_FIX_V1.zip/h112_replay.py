#!/usr/bin/env python3
"""Optional read-only-source native replay of H109/H110/H111 on user's checkout.

Executes retained audited tool packages. Inputs are only from this H112 bundle;
outputs are entirely under --out. Never edits the checkout source or mem/ROM.txt.
"""
from __future__ import annotations
import argparse, hashlib, json, subprocess, sys, zipfile
from pathlib import Path, PurePosixPath
from h112_audit import audit, check, STAGES

TOOLS = {
    109:'KYIV_H109_VECTOR_N2_FULL_RK4_GROUP_ROM_V1.zip',
    110:'KYIV_H110_H2_BIG_FRACTION_EVIDENCE_FIX_V1.zip',
    111:'KYIV_H111_HYPERBOLIC_COUPLED_DEMO_V1.zip',
}
FILES={s:f'H{s}_NATIVE_REPLAY_EVIDENCE_V1' for s in TOOLS}

def git(repo:Path,*args):
    return subprocess.run(['git',*args],cwd=repo,text=True,stdout=subprocess.PIPE,
                          stderr=subprocess.PIPE,encoding='utf8',errors='replace')

def verify_repo(repo:Path):
    a=git(repo,'rev-parse','--is-inside-work-tree')
    b=git(repo,'rev-parse','--show-prefix')
    check(a.returncode==0 and a.stdout.strip()=='true','not a Git checkout')
    check(b.returncode==0 and b.stdout.strip()=='','not repo root')
    check((repo/'mem'/'ROM.txt').is_file(),'mem/ROM.txt missing')
    return git(repo,'status','--porcelain').stdout

def extract_tool(src:Path,dst:Path):
    with zipfile.ZipFile(src) as z:
        for name in z.namelist():
            p=PurePosixPath(name)
            check(not p.is_absolute() and '..' not in p.parts and len(p.parts)==1,
                  'tool has unsafe entry '+name)
            if name.endswith('/'):continue
            (dst/name).write_bytes(z.read(name))

def compare_replay(reference_zip:Path,replay_zip:Path,stage:int):
    with zipfile.ZipFile(reference_zip) as a,zipfile.ZipFile(replay_zip) as b:
        aj=json.loads(a.read(f'RESULT_H{stage}.json'))
        bj=json.loads(b.read(f'RESULT_H{stage}.json'))
        check(aj['status']==bj['status'],f'H{stage}: replay status changed')
        check(set(aj['cases'])==set(bj['cases']),f'H{stage}: replay cases changed')
        for key,c in aj['cases'].items():
            d=bj['cases'][key]
            for field in ('status','n','points','native_instructions','output_raw41'):
                check(c[field]==d[field],f'H{stage}/{key}: replay differs in {field}')
            if stage>109:check(c['RHS_calls']==d['RHS_calls'],f'H{stage}/{key}: RHS count changed')
        # Retained machine trajectories provide the full raw41 sequence, not just final output.
        an=a.read(f'TRAJECTORY_H{stage}.tsv').decode('utf8').splitlines()
        bn=b.read(f'TRAJECTORY_H{stage}.tsv').decode('utf8').splitlines()
        check(len(an)==len(bn),f'H{stage}: row count changed')
        ah=an[0].split('\t');bh=bn[0].split('\t')
        cols=('case','step','x','y1_raw41','y2_raw41')
        for c in cols:check(c in ah and c in bh,f'H{stage}: {c} missing')
        for lineidx,(x,y) in enumerate(zip(an[1:],bn[1:]),start=1):
            av=x.split('\t');bv=y.split('\t')
            for field in cols:
                check(av[ah.index(field)]==bv[bh.index(field)],f'H{stage}: trace line {lineidx} {field}')

def replay(bundle:Path,repo:Path,out:Path,preflight=False):
    report=audit(bundle)
    prior=verify_repo(repo)
    check(not out.exists(),f'output directory already exists: {out} (refuse overwrite)')
    if preflight:
        print('H112_REPLAY_PREFLIGHT=PASS')
        print('H112_REPLAY_CASES='+str(report['native_scenarios_reexamined']))
        return
    out.mkdir(parents=True)
    evidence={103:bundle/'evidence'/STAGES[103], 108:bundle/'evidence'/STAGES[108]}
    results=[]
    try:
        for stage in TOOLS:
            dst=out/f'tool_h{stage}'
            dst.mkdir()
            extract_tool(bundle/'tools'/TOOLS[stage],dst)
            target=out/FILES[stage]
            args=[sys.executable,str(dst/f'h{stage}_run.py'),'--repo',str(repo)]
            if stage==109:args+=['--h108-evidence',str(evidence[108]),'--h103-evidence',str(evidence[103])]
            else:
                args+=['--h109-evidence',str(bundle/'evidence'/STAGES[109]),'--h103-evidence',str(evidence[103])]
                if stage==111: args+=['--h110-evidence',str(bundle/'evidence'/STAGES[110])]
            args+=['--out',str(target)]
            process=subprocess.run(args,cwd=repo,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,
                                   text=True,encoding='utf8',errors='replace')
            (out/f'RUN_H{stage}.log').write_text(process.stdout,encoding='utf8')
            check(process.returncode==0,f'H{stage}: tool exited {process.returncode}; inspect RUN_H{stage}.log')
            artifact=target.with_suffix('.zip')
            check(artifact.is_file(),f'H{stage}: native evidence ZIP not created')
            compare_replay(bundle/'evidence'/STAGES[stage],artifact,stage)
            evidence[stage]=artifact
            results.append({'stage':stage,'source_evidence':STAGES[stage],
                            'replay_sha256':hashlib.sha256(artifact.read_bytes()).hexdigest(),
                            'status':'PASS_REPLAY_MATCH'})
            print(f'H{stage}_REPLAY=PASS')
        check(git(repo,'status','--porcelain').stdout==prior,'Git worktree status changed')
        report={'status':'PASS_H112_NATIVE_REPLAY_THREE_SYSTEMS', 'stages':results,
                'worktree_status_unchanged':True}
        (out/'RESULT_H112_REPLAY.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
        print('H112_REPLAY_STATUS='+report['status'])
    except Exception as exc:
        (out/'HOLD_H112_REPLAY.txt').write_text(repr(exc)+'\n',encoding='utf8')
        print('H112_REPLAY_STATUS=HOLD_H112_NATIVE_REPLAY',file=sys.stderr)
        print('H112_REPLAY_ERROR='+repr(exc),file=sys.stderr)
        raise

def main():
    p=argparse.ArgumentParser();p.add_argument('--bundle',type=Path,default=Path(__file__).resolve().parent)
    p.add_argument('--repo',type=Path,required=True);p.add_argument('--out',type=Path)
    p.add_argument('--preflight-only',action='store_true');args=p.parse_args()
    repo=args.repo.resolve();bundle=args.bundle.resolve()
    out=(args.out or (repo/'tempkyiv'/'H112_NATIVE_REPLAY')).resolve()
    try:replay(bundle,repo,out,args.preflight_only)
    except Exception as e: print('H112_REPLAY_ERROR='+repr(e),file=sys.stderr);sys.exit(1)
if __name__=='__main__':main()
