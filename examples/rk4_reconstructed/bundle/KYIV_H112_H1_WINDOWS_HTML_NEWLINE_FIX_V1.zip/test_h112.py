#!/usr/bin/env python3
"""Non-mutating H112 offline regression and mutation tests (standard library)."""
import importlib.util, io, json, shutil, subprocess, sys, tempfile, unittest, zipfile
from pathlib import Path
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from h112_audit import audit,internal_integrity,signed_word,check
from h112_replay import compare_replay,verify_repo,replay
from h112_report import render

class Audit(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.result=audit(HERE)
    def test_accepted(self):self.assertEqual(self.result['status'],'PASS_H112_OFFLINE_EVIDENCE_AUDIT')
    def test_29_cases(self):self.assertEqual(self.result['native_scenarios_reexamined'],29)
    def test_3408_points(self):self.assertEqual(self.result['trajectory_points_reexamined'],3408)
    def test_known_machine_fractions(self):
        from fractions import Fraction
        self.assertEqual(signed_word('04000000000000'),Fraction(1,4))
        self.assertEqual(signed_word('22000000000000'),Fraction(-1,8))
    def test_reject_beyond_41_bits(self):
        with self.assertRaises(ValueError):signed_word('40000000000000')
    def test_reject_non_octal(self):
        with self.assertRaises(ValueError):signed_word('04000000000009')
    def test_reject_corrupted_outer_pin(self):
        with tempfile.TemporaryDirectory() as d:
            out=Path(d);(out/'evidence').mkdir();(out/'tools').mkdir()
            shutil.copyfile(HERE/'PINNED_INPUTS_H112.json',out/'PINNED_INPUTS_H112.json')
            rel='evidence/H103_GROUP_ALPHA_NATIVE_EVIDENCE_H2_V1.zip'
            (out/rel).write_bytes(b'corrupted')
            with self.assertRaisesRegex(ValueError,'PIN_MISMATCH'):audit(out)
    def test_reject_corrupted_member_crc(self):
        original=HERE/'evidence'/'H111_HYPERBOLIC_COUPLED_NATIVE_EVIDENCE_V1.zip'
        with zipfile.ZipFile(original) as z:
            data=io.BytesIO()
            with zipfile.ZipFile(data,'w',zipfile.ZIP_DEFLATED) as out:
                out.writestr('RESULT_H111.json',b'{}')
                out.writestr('SHA256SUMS.txt',z.read('SHA256SUMS.txt'))
        with zipfile.ZipFile(data) as altered:
            with self.assertRaises(ValueError):internal_integrity(altered,'altered')
    def test_reject_mutated_native_result(self):
        original=HERE/'evidence'/'H109_VECTOR_N2_FULL_NATIVE_EVIDENCE_V1.zip'
        with zipfile.ZipFile(original) as z:
            data=io.BytesIO()
            with zipfile.ZipFile(data,'w',zipfile.ZIP_DEFLATED) as out:
                for name in z.namelist():
                    b=z.read(name)
                    if name=='RESULT_H109.json':
                        j=json.loads(b);j['cases']['n3_negative_pattern']['native_instructions']+=1
                        b=json.dumps(j).encode()
                    out.writestr(name,b)
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'replay.zip';p.write_bytes(data.getvalue())
            with self.assertRaisesRegex(ValueError,'native_instructions'):compare_replay(original,p,109)
    def test_replay_matches_self(self):
        src=HERE/'evidence'/'H110_COUPLED_VECTOR_NATIVE_EVIDENCE_H2_V1.zip'
        compare_replay(src,src,110)
    def test_html_regeneration_from_evidence(self):
        with tempfile.TemporaryDirectory() as d:
            out=Path(d)/'report.html'
            r=render(HERE,out)
            self.assertEqual(r['status'],'PASS_H112_HTML_FROM_PINNED_NATIVE_EVIDENCE')
            self.assertIn('Чисельне інтегрування',out.read_text(encoding='utf8'))
            self.assertEqual(out.read_bytes(),(HERE/'DEMO_H112.html').read_bytes())
    def test_replay_preflight_accepts_git_root(self):
        with tempfile.TemporaryDirectory() as d:
            repo=Path(d)/'repo';repo.mkdir()
            subprocess.run(['git','init','-q'],cwd=repo,check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
            (repo/'mem').mkdir();(repo/'mem'/'ROM.txt').write_bytes(b'')
            replay(HERE,repo,repo/'tempkyiv'/'REPLAY',preflight=True)
            self.assertFalse((repo/'tempkyiv').exists())
            with self.assertRaisesRegex(ValueError,'not repo root'):
                verify_repo(repo/'mem')
    def test_legacy_scope_not_claimed(self):
        limitations=' '.join(self.result['limitations'])
        self.assertIn('n=2',limitations)
        self.assertIn('3200',limitations)
if __name__=='__main__':unittest.main(verbosity=2)
